=== WP Bitcoin Newsletter (Pay-per-Subscribe) ===
Contributors: yourname
Tags: newsletter, bitcoin, lightning, mailchimp, mailpoet, btcpay
Requires at least: 6.0
Tested up to: 6.6
Stable tag: 0.1.0
License: GPLv2 or later

WP Bitcoin Newsletter requires a successful Bitcoin Lightning payment before subscribing users to a newsletter provider.

== Description ==
This plugin lets you create newsletter forms (as a custom post type) and only register subscribers after a successful Lightning payment using Coinsnap or BTCPay Server. It supports multiple newsletter providers (MailPoet, Mailchimp, Sendinblue/Brevo, ConvertKit, or WP database only).

== Installation ==
1. Upload or install the plugin zip in WordPress.
2. Activate the plugin.
3. Go to Subscribers > Settings to configure payment and newsletter providers.
4. Create a form under Subscribers > Newsletter Forms and use the shortcode: [coinsnap_newsletter_form id="123"].

== Changelog ==
0.1.0 - Initial scaffolding release.

